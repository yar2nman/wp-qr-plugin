
<?php

public function registerAndBuildFields() {
         /**
        * First, we add_settings_section. This is necessary since all future settings must belong to one.
        * Second, add_settings_field
        * Third, register_setting
        */     
add_settings_section(
      // ID used to identify this section and with which to register options
      'ux_qr_general_section', 
      // Title to be displayed on the administration page
      '',  
      // Callback used to render the description of the section
       array( $this, 'ux_qr_display_general_account' ),    
      // Page on which to add this section of options
      'ux_qr_general_settings'                   
    );
    unset($args);
    $args = array (
              'type'      => 'input',
              'subtype'   => 'text',
              'id'    => 'ux_qr_example_setting',
              'name'      => 'ux_qr_example_setting',
              'required' => 'true',
              'get_options_list' => '',
              'value_type'=>'normal',
              'wp_data' => 'option'
          );
    add_settings_field(
      'ux_qr_example_setting',
      'Example Setting',
      array( $this, 'ux_qr_render_settings_field' ),
      'ux_qr_general_settings',
      'ux_qr_general_section',
      $args
    );


    register_setting(
            'ux_qr_general_settings',
            'ux_qr_example_setting'
            );

}


public function ux_qr_display_general_account() {
    echo '<p>These settings apply to all Plugin Name functionality.</p>';
  } 


  public function ux_qr_render_settings_field($args) {
    /* EXAMPLE INPUT
              'type'      => 'input',
              'subtype'   => '',
              'id'    => $this->plugin_name.'_example_setting',
              'name'      => $this->plugin_name.'_example_setting',
              'required' => 'required="required"',
              'get_option_list' => "",
                'value_type' = serialized OR normal,
    'wp_data'=>(option or post_meta),
    'post_id' =>
    */     
if($args['wp_data'] == 'option'){
   $wp_data_value = get_option($args['name']);
} elseif($args['wp_data'] == 'post_meta'){
   $wp_data_value = get_post_meta($args['post_id'], $args['name'], true );
}

switch ($args['type']) {

   case 'input':
       $value = ($args['value_type'] == 'serialized') ? serialize($wp_data_value) : $wp_data_value;
       if($args['subtype'] != 'checkbox'){
           $prependStart = (isset($args['prepend_value'])) ? '<div class="input-prepend"> <span class="add-on">'.$args['prepend_value'].'</span>' : '';
           $prependEnd = (isset($args['prepend_value'])) ? '</div>' : '';
           $step = (isset($args['step'])) ? 'step="'.$args['step'].'"' : '';
           $min = (isset($args['min'])) ? 'min="'.$args['min'].'"' : '';
           $max = (isset($args['max'])) ? 'max="'.$args['max'].'"' : '';
           if(isset($args['disabled'])){
               // hide the actual input bc if it was just a disabled input the informaiton saved in the database would be wrong - bc it would pass empty values and wipe the actual information
               echo $prependStart.'<input type="'.$args['subtype'].'" id="'.$args['id'].'_disabled" '.$step.' '.$max.' '.$min.' name="'.$args['name'].'_disabled" size="40" disabled value="' . esc_attr($value) . '" /><input type="hidden" id="'.$args['id'].'" '.$step.' '.$max.' '.$min.' name="'.$args['name'].'" size="40" value="' . esc_attr($value) . '" />'.$prependEnd;
           } else {
               echo $prependStart.'<input type="'.$args['subtype'].'" id="'.$args['id'].'" "'.$args['required'].'" '.$step.' '.$max.' '.$min.' name="'.$args['name'].'" size="40" value="' . esc_attr($value) . '" />'.$prependEnd;
           }
           /*<input required="required" '.$disabled.' type="number" step="any" id="'.$this->plugin_name.'_cost2" name="'.$this->plugin_name.'_cost2" value="' . esc_attr( $cost ) . '" size="25" /><input type="hidden" id="'.$this->plugin_name.'_cost" step="any" name="'.$this->plugin_name.'_cost" value="' . esc_attr( $cost ) . '" />*/

       } else {
           $checked = ($value) ? 'checked' : '';
           echo '<input type="'.$args['subtype'].'" id="'.$args['id'].'" "'.$args['required'].'" name="'.$args['name'].'" size="40" value="1" '.$checked.' />';
       }
       break;
   default:
       # code...
       break;
}
}